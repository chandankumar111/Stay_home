/**
 * Property model for PG, Flat, Room listings
 */

const mongoose = require('mongoose');

const propertySchema = new mongoose.Schema({
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  type: {
    type: String,
    enum: ['pg', 'flat', 'room'],
    required: true
  },
  address: {
    type: String,
    required: true
  },
  location: {
    // GeoJSON Point for Mapbox integration
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number], // [longitude, latitude]
      required: true
    }
  },
  price: {
    type: Number,
    required: true
  },
  photos: [
    {
      type: String // URLs or file paths
    }
  ],
  videos: [
    {
      type: String // URLs or file paths
    }
  ],
  available: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create 2dsphere index for location queries
propertySchema.index({ location: '2dsphere' });

module.exports = mongoose.model('Property', propertySchema);
