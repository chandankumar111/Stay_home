/**
 * Booking controller for managing bookings and payments
 */

const Booking = require('../models/Booking');
const Property = require('../models/Property');
const Razorpay = require('razorpay');
const crypto = require('crypto');

// Initialize Razorpay instance
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Create a new booking and generate Razorpay order
exports.createBooking = async (req, res) => {
  try {
    const userId = req.user.id;
    const { propertyId, startDate, endDate, amount } = req.body;

    // Check if property exists and is available
    const property = await Property.findById(propertyId);
    if (!property || !property.available) {
      return res.status(400).json({ message: 'Property not available' });
    }

    // Create Razorpay order
    const options = {
      amount: amount * 100, // amount in paise
      currency: 'INR',
      receipt: `receipt_${Date.now()}`,
      payment_capture: 1
    };

    const order = await razorpay.orders.create(options);

    // Create booking with status pending
    const booking = new Booking({
      user: userId,
      property: propertyId,
      startDate,
      endDate,
      amount,
      status: 'pending',
      paymentId: order.id
    });

    await booking.save();

    res.json({ booking, order });
  } catch (error) {
    console.error('Create booking error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Verify payment and update booking status
exports.verifyPayment = async (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

    const booking = await Booking.findOne({ paymentId: razorpay_order_id });
    if (!booking) {
      return res.status(400).json({ message: 'Booking not found' });
    }

    // Verify signature
    const generated_signature = crypto
      .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
      .update(razorpay_order_id + '|' + razorpay_payment_id)
      .digest('hex');

    if (generated_signature !== razorpay_signature) {
      return res.status(400).json({ message: 'Invalid payment signature' });
    }

    // Update booking status to confirmed
    booking.status = 'confirmed';
    await booking.save();

    res.json({ message: 'Payment verified and booking confirmed', booking });
  } catch (error) {
    console.error('Verify payment error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get bookings for logged-in user
exports.getUserBookings = async (req, res) => {
  try {
    const userId = req.user.id;
    const bookings = await Booking.find({ user: userId }).populate('property');
    res.json(bookings);
  } catch (error) {
    console.error('Get user bookings error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};
