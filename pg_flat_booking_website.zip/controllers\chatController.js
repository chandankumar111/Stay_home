/**
 * Chat controller for managing chat history and messages
 */

const Chat = require('../models/Chat');

// Get chat history between two users
exports.getChatHistory = async (req, res) => {
  try {
    const userId = req.user.id;
    const otherUserId = req.params.userId;

    // Find chat between the two participants
    let chat = await Chat.findOne({
      participants: { $all: [userId, otherUserId] }
    }).populate('messages.sender', 'name email');

    if (!chat) {
      return res.json({ messages: [] });
    }

    res.json({ messages: chat.messages });
  } catch (error) {
    console.error('Get chat history error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Add a new message to chat
exports.addMessage = async (req, res) => {
  try {
    const userId = req.user.id;
    const { recipientId, message } = req.body;

    // Find or create chat between participants
    let chat = await Chat.findOne({
      participants: { $all: [userId, recipientId] }
    });

    if (!chat) {
      chat = new Chat({
        participants: [userId, recipientId],
        messages: []
      });
    }

    chat.messages.push({
      sender: userId,
      message
    });

    await chat.save();

    res.json({ message: 'Message sent', chat });
  } catch (error) {
    console.error('Add message error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};
