/**
 * Chat routes for fetching chat history and sending messages
 */

const express = require('express');
const router = express.Router();
const chatController = require('../controllers/chatController');
const { authenticateJWT } = require('../middleware/auth');

// Get chat history with another user
router.get(
  '/:userId',
  authenticateJWT,
  chatController.getChatHistory
);

// Send a new message
router.post(
  '/',
  authenticateJWT,
  chatController.addMessage
);

module.exports = router;
