/**
 * Property controller for owner CRUD operations
 */

const Property = require('../models/Property');

// Create a new property
exports.createProperty = async (req, res) => {
  try {
    const ownerId = req.user.id;
    const {
      title,
      description,
      type,
      address,
      location, // { coordinates: [lng, lat] }
      price,
      photos,
      videos,
      available
    } = req.body;

    const property = new Property({
      owner: ownerId,
      title,
      description,
      type,
      address,
      location,
      price,
      photos,
      videos,
      available: available !== undefined ? available : true
    });

    await property.save();
    res.status(201).json(property);
  } catch (error) {
    console.error('Create property error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all properties for the logged-in owner
exports.getOwnerProperties = async (req, res) => {
  try {
    const ownerId = req.user.id;
    const properties = await Property.find({ owner: ownerId });
    res.json(properties);
  } catch (error) {
    console.error('Get owner properties error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update a property by ID (owner only)
exports.updateProperty = async (req, res) => {
  try {
    const ownerId = req.user.id;
    const propertyId = req.params.id;

    let property = await Property.findOne({ _id: propertyId, owner: ownerId });
    if (!property) {
      return res.status(404).json({ message: 'Property not found or unauthorized' });
    }

    const updates = req.body;
    property = await Property.findByIdAndUpdate(propertyId, updates, { new: true });
    res.json(property);
  } catch (error) {
    console.error('Update property error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Delete a property by ID (owner only)
exports.deleteProperty = async (req, res) => {
  try {
    const ownerId = req.user.id;
    const propertyId = req.params.id;

    const property = await Property.findOneAndDelete({ _id: propertyId, owner: ownerId });
    if (!property) {
      return res.status(404).json({ message: 'Property not found or unauthorized' });
    }

    res.json({ message: 'Property deleted successfully' });
  } catch (error) {
    console.error('Delete property error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all available properties with optional filters (for users)
exports.getAvailableProperties = async (req, res) => {
  try {
    const { type, minPrice, maxPrice, lng, lat, radius } = req.query;

    let filter = { available: true };

    if (type) {
      filter.type = type;
    }

    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }

    if (lng && lat && radius) {
      filter.location = {
        $geoWithin: {
          $centerSphere: [
            [Number(lng), Number(lat)],
            Number(radius) / 6378.1 // radius in radians (km)
          ]
        }
      };
    }

    const properties = await Property.find(filter);
    res.json(properties);
  } catch (error) {
    console.error('Get available properties error:', error.message);
    res.status(500).json({ message: 'Server error' });
  }
};
