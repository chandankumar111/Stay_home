/**
 * Property routes for owner and user
 */

const express = require('express');
const router = express.Router();
const propertyController = require('../controllers/propertyController');
const { authenticateJWT, authorizeRoles } = require('../middleware/auth');

// Owner routes - CRUD properties
router.post(
  '/',
  authenticateJWT,
  authorizeRoles('owner'),
  propertyController.createProperty
);

router.get(
  '/owner',
  authenticateJWT,
  authorizeRoles('owner'),
  propertyController.getOwnerProperties
);

router.put(
  '/:id',
  authenticateJWT,
  authorizeRoles('owner'),
  propertyController.updateProperty
);

router.delete(
  '/:id',
  authenticateJWT,
  authorizeRoles('owner'),
  propertyController.deleteProperty
);

// User route - get available properties with filters
router.get(
  '/',
  authenticateJWT,
  authorizeRoles('user', 'admin'),
  propertyController.getAvailableProperties
);

module.exports = router;
