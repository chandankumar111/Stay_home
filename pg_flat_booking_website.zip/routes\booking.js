/**
 * Booking routes for users
 */

const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');
const { authenticateJWT, authorizeRoles } = require('../middleware/auth');

// Create a new booking and generate Razorpay order
router.post(
  '/',
  authenticateJWT,
  authorizeRoles('user'),
  bookingController.createBooking
);

// Verify payment and confirm booking
router.post(
  '/verify',
  authenticateJWT,
  authorizeRoles('user'),
  bookingController.verifyPayment
);

// Get bookings for logged-in user
router.get(
  '/',
  authenticateJWT,
  authorizeRoles('user'),
  bookingController.getUserBookings
);

module.exports = router;
